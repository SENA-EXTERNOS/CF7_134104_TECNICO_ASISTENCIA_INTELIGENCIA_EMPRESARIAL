function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5VgbD4S0phZ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

